import { useState } from 'react'
import ImageUpload  from './components/UploadImage'
// import styles from './components/photoTaggingStyles.css'

function App() {
  return (
    <>
      <ImageUpload />
    </>
  )
}

export default App

import React, { useState } from 'react';
import axios from 'axios';
import ImagePoster from './ImgPoster';
// import './photoTaggingStyles.css';

const ImageUpload = () => {
  const [selectedImage, setSelectedImage] = useState(null);
  const [imgUploaded, setImgUploaded] = useState(false);

  const handleImageChange = (event) => {
    const file = event.target.files[0];
    setSelectedImage(URL.createObjectURL(file));
  };

  const handleImageUpload = () => {
    // Implement your image upload logic here
    // You can use the 'selectedImage' state to access the uploaded image
    console.log('Uploading image...');
    if (!selectedImage) {
      console.log('No image selected');
      return;
    }
    setImgUploaded(true)
    setSelectedImage(null)
   
    // const formData = new FormData();
    // formData.append('image', selectedImage);

    // axios
    //   .post('http://localhost:3000/upload', formData)
    //   .then((response) => {
    //     console.log(response.data.message);
    //   })
    //   .catch((error) => {
    //     console.error('Error uploading image:', error);
    //   });
  };

  return (
    <div>
      <h2>Image Upload</h2>
      <input type="file" accept="image/*" onChange={handleImageChange} />
      <button onClick={handleImageUpload}>Upload</button>
      {selectedImage && (
        <>
                <div> 
          <h3>Selected Image:</h3>
          <img src={selectedImage} alt="Selected" />
        </div>
        
        </>

      ) }
      {imgUploaded && (
        <ImagePoster/>
      )}
    </div>
  );
};

export default ImageUpload
